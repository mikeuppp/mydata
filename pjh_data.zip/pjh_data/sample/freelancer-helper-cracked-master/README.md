## Freelancer Help Cracked

<div align="center" style="display: flex;"> 
  <img alt="Stars" src="https://img.shields.io/github/stars/oscaryang-k/freelancer-helper-cracked?style=for-the-badge">
  <img alt="Forks" src="https://img.shields.io/github/forks/oscaryang-k/freelancer-helper-cracked?style=for-the-badge">
  <img alt="Issues" src="https://img.shields.io/github/issues/oscaryang-k/freelancer-helper-cracked?style=for-the-badge">
  <img alt="Pull Requests" src="https://img.shields.io/github/issues-pr/oscaryang-k/freelancer-helper-cracked?style=for-the-badge">
  <img alt="GitHub code size in bytes" src="https://img.shields.io/github/languages/code-size/oscaryang-k/freelancer-helper-cracked?style=for-the-badge">
</div>

### [Chrome Extension](https://chrome.google.com/webstore/detail/freelancer-helper/hekceblplbphdfpmofgnpccibieilafn?hl=en)
Freelancer.com No.1 extension with cracked. This extension makes using freelancer.com an easier and less frustrating experience. Hopefully it will save you lots of time and stress. Enjoy Freelancing.

Improvements for freelancer.com. Hiding projects by country, showing employer details...
This extension makes using freelancer.com an easier and less frustrating experience. Hopefully it will save you lots of time and stress.

## All Features are cracked :
- Show employer name and link to their profile on each project.
- Let you view employer reviews on employer profile.

Premium tier features:
- Hide projects from employers basing on what country they are from. Unfortunately we all know there are some countries with an ungodly amount of spam projects.
- Hide projects basing on what tags the project has or on employer verifications or name.
- Increase the amount of projects shown on the search page from the default of 10. This is especially useful if your other filters remove many projects and you are often left with none.
- In addition to employer name, also view their project statistics to decide if they are likely to award the project. There are many employers who post hundreds of projects but never award, which is a waste of a bid and time. Also view the employer avatar.
- Open the project attachments in the browser
- Only show projects with a maximum of some bids
- Show employer country flag on the search page.

This is cracked version so you can use this project for free.
